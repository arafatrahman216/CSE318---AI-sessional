class Dimension:
    def __init__(self):
        self.ROWS = 9
        self.COLS = 6
        self.heuristicBlue = "orb_diff"
        self.heuristicRed = "cell_diff"

dimension = Dimension()
